# 🚀 Bot WhatsApp Loja

### ✅ Passo a passo

1. Crie um repositório no GitHub com nome `bot-whatsapp-loja`
2. Suba os arquivos deste ZIP para o repositório
3. Adicione suas fotos na pasta `/images` e copie os links `raw` para o arquivo `fotos.json`
4. Conecte o GitHub ao Railway (Empty Project → GitHub → escolha o repositório)
5. O Railway vai buildar automaticamente
6. No log, escaneie o QR code com seu WhatsApp
7. Pronto! Bot online 🚗💬

---
### 💡 Fotos

Edite `fotos.json` para incluir os links das fotos reais (raw link do GitHub).

---
### ✉️ Suporte

Se precisar, é só chamar! 🚀
